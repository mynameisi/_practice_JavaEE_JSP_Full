package edu.unsw.comp9321;

import java.util.*; 

import java.io.Serializable;

/*
 * Changed the name of Journey object to JourneyBean. As you can see, the actual code hasn't changed much
 */
public class JourneyBean implements Serializable { 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Vector<String> places;

	public JourneyBean() { 
		places = new Vector<String>(); 
	} 
	
	public Vector<String> getPlaces() { 
		return places; 
	} 
	
	public void setPlaces(Vector<String> places) {
		this.places = places;
	}
	
	public String toString() { return "JourneyBean to "; }
}